/*
 * DuyDuc94
 */
package Function;

import Object.*;

/**
 *
 * @author duy20
 * @param <T>
 */
public class MyLinkedList<T> {

    Node<T> head, tail, contain;
    
    public MyLinkedList() {
        head = tail = null;
    }
//==============================================================================
    public boolean isEmpty() {
        return head == null;
    }
//==============================================================================    
    public void clear() {
        head = tail = null;
        System.out.println("\nList has clear!");
    }
//==============================================================================
    //Check duplicated by code (key)
    public boolean checkDuplicate(T newData) {
        Node<T> needCheck = new Node<>(newData);
        Node<T> curNode = head;
        while (curNode != null) {
            if (curNode.getKey().compareTo(needCheck.getKey()) == 0) {
                System.out.println("Data has exist! " + needCheck.getKey());
                return true;
            }
            curNode = curNode.getNextNode();
        }
        return false;
    }
//==============================================================================
    public boolean checkDuplicate(String needCheck) {
        Node<T> curNode = head;
        while (curNode != null) {
            if (curNode.getKey().compareTo(needCheck) == 0) {
                System.out.println("Data has exist! " + needCheck);
                return true;
            }
            curNode = curNode.getNextNode();
        }
        return false;
    }
//==============================================================================
    ////Add new node to the end of list
    public void addLast(T newData) {
        if (newData == null) {
            return;
        }
        Node<T> newNode = new Node<>(newData);
        if (head == null) {
            head = tail = newNode;
            System.out.println("Add " + newNode.getData() + " successfully!");
        } else {
            if (!checkDuplicate(newData)) {
                tail.setNextNode(newNode);
                tail = newNode;
                System.out.println("Add " + newNode.getData() + " successfully!");
            }
        }
    }
//==============================================================================
    //Traverse and display all node of list
    public void traverse() {
        Node<T> current = head;
        while (current != null) {
            printWithFormat(current);
            current = current.getNextNode();
        }
    }
//==============================================================================
    public void printWithFormat(Node needVisit) {
        if (needVisit != null) {
            if (needVisit.getData() instanceof Product) {
                Product tempProduct = (Product) needVisit.getData();
                tempProduct.display();
            }
            if (needVisit.getData() instanceof Customer) {
                Customer tempCustomer = (Customer) needVisit.getData();
                tempCustomer.display();
            }
            if (needVisit.getData() instanceof Order) {
                Order tempOrder = (Order) needVisit.getData();
                tempOrder.display();
            }
        }
    }
//==============================================================================
    //Return String to write file
    public String getData() {
        String result = "";
        Node<T> currNode = head;
        while (currNode != null) {
            result += getDataLineOf(currNode);
            currNode = currNode.getNextNode();
        }
        return result;
    }

    public String getDataLineOf(Node needVisit) {
        if (needVisit != null) {
            if (needVisit.getData() instanceof Product) {
                Product tempProduct = (Product) needVisit.getData();
                return tempProduct.getDataLine();
            }
            if (needVisit.getData() instanceof Customer) {
                Customer tempCustomer = (Customer) needVisit.getData();
                return tempCustomer.getDataLine();
            }
        }
        return "";
    }
//==============================================================================
    //Search and return Node has same Code (Key)
    public Node search(String xCode) {
        Node currNode = head;
        while (currNode != null) {
            if (currNode.getKey().compareTo(xCode) == 0) {
                return currNode;
            }
            currNode = currNode.getNextNode();
        }
        if(this.head.getData() instanceof Product){
            System.out.println("\nNot found product!");
            return null;
        }
        if(this.head.getData() instanceof Customer){
            System.out.println("\nNot found customer!");
            return null;
        }
        System.out.println("\nNot found!");
        return null;
    }
//==============================================================================
    public void deleteAfter(Node node) {
        Node currNode = head;
        while (currNode != null) {
            if (currNode == node) {
                break;
            }
            currNode = currNode.getNextNode();
        }
        if (currNode.getNextNode() == null) {
            System.out.println("\nDon't exist its after node!");
            return;
        }
        delete(currNode.getNextNode());
    }
//==============================================================================
    //Remove node from the list
    public void delete(Node needRemove) {
        //==============Check if node need delete is exist or not===============
        if (needRemove == null) return;
        Node currNode = head, beforeCurrNode = null;
        //===========================Delete node================================
        //Loop until find currNode that equal to node needRemove
        while (currNode != null) {
            if (currNode.getData() == needRemove.getData())
                break;
            beforeCurrNode = currNode;
            currNode = currNode.getNextNode();
        }
        //If beforeCurrPoint == null that means node needRemove is head, then simply delete the head
        if (beforeCurrNode == null) {
            head = head.getNextNode();
        //Else if currNode is last node of list (tail), set beforeCurrNode be new tail, and delete currNode
        } else if(currNode.getNextNode() == null){
            beforeCurrNode.setNextNode(null);
            tail = beforeCurrNode;
        }else{
            beforeCurrNode.setNextNode(currNode.getNextNode());
        }
        //==================Display message of success delete===================
        if(head.getData() instanceof Product){
            Product tempProduct = (Product) needRemove.getData();
            System.out.println("\nDelete " + tempProduct + " successfully!");
            return;
        }
        if(head.getData() instanceof Customer){
            Customer tempCustomer = (Customer) needRemove.getData();
            System.out.println("\nDelete " + tempCustomer + " successfully!");
            return;
        }
    }
//==============================================================================
    public void sortByCode() {
        if(isEmpty()) return;
        Node NodeI = head, NodeJ, tempNode = new Node(null);
        ////Bubble sort (swap only data): sort ascending, less value up to head
        while (NodeI != null) {
            NodeJ = NodeI.getNextNode();
            while (NodeJ != null) {
                //Swap data ascending by name
                if (NodeI.getKey().compareTo(NodeJ.getKey()) > 0) {
                    tempNode.setData(NodeI.getData());
                    NodeI.setData(NodeJ.getData());
                    NodeJ.setData(tempNode.getData());
                }
                NodeJ = NodeJ.getNextNode();
            }
            NodeI = NodeI.getNextNode();
        }
        System.out.println("\nComplete the ascending sort by code");
    }
//==============================================================================
    //Return node at the position index
    public Node atPosition(int index) {
        Node currNode = head;
        int indexInLoop = 0;
        while (currNode != null) {
            if (indexInLoop == index) {
                return currNode;
            }
            currNode = currNode.getNextNode();
            indexInLoop++;
        }
        System.out.println("\nNot found!");
        return null;
    }
//==============================================================================
    public void insertAfter(Node needInsertAfter, T newData) {
        if (!checkDuplicate(newData)) {
            Node newNode = new Node(newData);
            Node tempNode = needInsertAfter.getNextNode();
            needInsertAfter.setNextNode(newNode);
            newNode.setNextNode(tempNode);
            System.out.println("\nAdd " + newData + " successfully!");
        }
    }
//==============================================================================
    public void subtractQuantityOrder(String pCode, int quantityOrder){
        Product tempProduct = (Product) search(pCode).getData();
        try {
            search(pCode).setData(new Product(tempProduct.getProductCode(), tempProduct.getProductName(), tempProduct.getQuantity(), tempProduct.getSaled()+quantityOrder, tempProduct.getPrice()));
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    } 
//==============================================================================
}


