/*
 * DuyDuc94
 */
package GUI;

import Function.*;
import Object.Node;
import Object.Product;
import java.io.*;

/**
 *
 * @author duy20
 */
public class ProductMenu {

    public static MyLinkedList<Product> productList = new MyLinkedList();

    public static void productMenu() {
        while (true) {
            System.out.println("\n==============================================");
            System.out.println("Product list (8 marks):");
            System.out.println("1.1.      Load data from file");
            System.out.println("1.2.      Clear the list");
            System.out.println("1.3.      Input & add to the end");
            System.out.println("1.4.      Display data");
            System.out.println("1.5.      Save product list to file");
            System.out.println("1.6.      Search by pcode");
            System.out.println("1.7.      Delete by pcode");
            System.out.println("1.8.      Sort by pcode");
            System.out.println("1.9.      Add after position k");
            System.out.println("1.10.      Delete the node after the node having code = xCode");
            /*Addition*/ System.out.println("1.11.     Return to menu");
            switch (ValidationInput.inputUserChoice(1, 11)) {
                case 1:
                    loadDataFromFile();
                    break;
                case 2:
                    productList.clear();
                    break;
                case 3:
                    productList.addLast(ValidationInput.inputProductData());
                    break;
                case 4:
                    displayData();
                    break;
                case 5:
                    saveProductListToFile();
                    break;
                case 6:
                    searchByProductCode();
                    break;
                case 7:
                    deleteByProductCode();
                    break;
                case 8:
                    productList.sortByCode();
                    break;
                case 9:
                    insertAfterPosition();
                    break;
                case 10:
                    delNodeAfterXCode();
                    break;
                case 11:
                    return;
            }
        }
    }
//==============================================================================
    public static void loadDataFromFile() {
        String filePath;
        FileReader dataFile;
        BufferedReader bufferReader;
        String readString;
        boolean isFileEmpty = true;
        /*Auto add data*/ filePath = "D:\\Specialized - SE1731\\Ki3_Spring 2023\\CSD201 (Data Structures and Algorithms) - OanhNT75\\JavaCode\\CSD201_Sale_Management_System_HE172114\\src\\Data\\ProductData_SaleManagementSystem.txt";
//        filePath = ValidationInput.inputString("Input path of file contain data: ");
        System.out.println("");
        //==========================Check file exist============================
        try {
            dataFile = new FileReader(filePath);
        } catch (FileNotFoundException e) {
            System.out.println("File doesn't exist! Create or correct path file!");
            return;
        }
        //=============================Read file================================
        bufferReader = new BufferedReader(dataFile);
        try {
            int countLine = 0;
            //Loop use to read every single line of file till end of file
            while ((readString = bufferReader.readLine()) != null) {
                countLine++;
                System.out.print("Line " + countLine + ": ");
                //Load every single line to data of list (must follow format)
                loadDataWithFormat(readString, countLine);
                isFileEmpty = false;
            }
            //Check file data is empty or load data success
            if (isFileEmpty) {
                System.out.println("File data is empty!");
            } else {
                System.out.println("Add data successfully!");
            }
            bufferReader.close();
        } catch (IOException ex) {
            System.out.print("An error has occur: ");
            System.out.println(ex);
        }
    }
//==============================================================================
    //Transfer single line contain data to data of linked list
    public static void loadDataWithFormat(String stringLine, int numberLine) {
        //Check line is empty or contain only white spaces
        if (stringLine.trim().isEmpty()) {
            System.out.println("Line is empty!");
            return;
        }
        //==================Format data to transfer to list=====================
        String[] data = stringLine.split("\\|");
        try {
            String productCode = data[0].trim();
            String productName = data[1].trim();
            int quantity = Integer.parseInt(data[2].trim());
            int saled = Integer.parseInt(data[3].trim());
            double price = Double.parseDouble(data[4].trim());
            productList.addLast(new Product(productCode, productName, quantity, saled, price));
        } catch (NumberFormatException e) {
            System.out.println("Data doesn't follow format!");
        } catch (Exception productEx) {
            System.out.println("Cannot add product because " + productEx.getMessage());
        }
    }
//==============================================================================
    public static void displayData() {
        if (productList.isEmpty()){
            System.out.println("\nProduct list is empty!");
            return;
        }
        System.out.println("\ncode |   Pro_name  |  Quantity  |  saled |  Price   |   Value");
        System.out.println("---------------------------------------------------------------");
        productList.traverse();
    }
//==============================================================================
    public static void saveProductListToFile() {
        String fileName = ValidationInput.inputString("Input file name to save data: ");
        System.out.println("");
        //Get current directory where program is running
        String curentDir = System.getProperty("user.dir");
        //==========================Create new file=============================
        File dataFile = new File(curentDir + "\\src\\Data\\" + fileName + ".txt");
        try {
            //Check file is exist or not
            if (dataFile.createNewFile()) {
                System.out.println("Create " + fileName + ".txt succesfully!");
            } else {
                System.out.println("File already exist!");
            }
        } catch (IOException ex) {
            System.out.print("An error has occur: ");
            System.out.println(ex.getMessage());
            return;
        }
        System.out.println("File located at " + dataFile.getAbsolutePath());
        //========================Write data into file==========================
        try {
            try (FileWriter fileWriter = new FileWriter(dataFile)) {
                fileWriter.write("code |   Pro_name  |  Quantity  |  saled |  Price   |   Value\n");
                fileWriter.write("---------------------------------------------------------------\n");
                fileWriter.write(productList.getData());
            }
            System.out.println("Successfully write data on file.");
        } catch (IOException ex) {
            System.out.print("An error has occur: ");
            System.out.println(ex.getMessage());
        }
    }
//==============================================================================
    public static void searchByProductCode() {
        if (productList.isEmpty()){
            System.out.println("\nProduct list is empty!");
            return;
        }
        Node tempNode;
        Product tempProduct;
        //Search by product code, if not found "search()" will return null
        if((tempNode = productList.search(ValidationInput.inputString("Input product code need to search: "))) == null)
            return;
        tempProduct = (Product) tempNode.getData();
        System.out.println("\nFound " + tempProduct + "!");
    }
//==============================================================================
    public static void deleteByProductCode() {
        if (productList.isEmpty()){
            System.out.println("\nProduct list is empty!");
            return;
        }
        Node tempNode;
        if((tempNode = productList.search(ValidationInput.inputString("Input product code need delete: "))) == null)
            return;
        productList.delete(tempNode);
    }
//==============================================================================
    public static void insertAfterPosition() {
        if (productList.isEmpty()){
            System.out.println("\nProduct list is empty!");
            return;
        }
        Node nodeAtPositionK;
        if ((nodeAtPositionK = productList.atPosition(ValidationInput.inputInt("Input position k: "))) == null)
            return;
        Product tempProduct;
        if ((tempProduct = ValidationInput.inputProductData()) != null) {
            productList.insertAfter(nodeAtPositionK, tempProduct);
        }
    }
//==============================================================================
    public static void delNodeAfterXCode() {
        if (productList.isEmpty()){
            System.out.println("\nProduct list is empty!");
            return;
        }
        Node tempNode;
        if((tempNode = productList.search(ValidationInput.inputString("Input code of node want to delete its after node: "))) == null) 
            return;
        productList.deleteAfter(tempNode);
    }
//==============================================================================
}
